FreeRTOS+Nabto projects are currently provided in a separate 
download.  Following are links to the download page and the
documentation for the demo that is included in the download.

http://www.freertos.org/FreeRTOS-Plus/Nabto/download_freertos_plus_nabto.shtml
http://www.freertos.org/FreeRTOS-Plus/Nabto/getting_started_with_FreeRTOS_Plus_Nabto.shtml